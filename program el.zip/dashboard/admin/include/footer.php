<footer class="footer">
            <span class="text-right">
                Copyright <a target="_blank" href="#">Elkiranaa</a> - <?php echo date('Y'); ?>
            </span>
        </footer>

        <script src="../assets/js/modernizr.min.js"></script>
        <script src="../assets/js/jquery.min.js"></script>
        <script src="../assets/js/moment.min.js"></script>

        <script src="../assets/js/popper.min.js"></script>
        <script src="../assets/js/bootstrap.min.js"></script>

        <script src="../assets/js/detect.js"></script>
        <script src="../assets/js/fastclick.js"></script>
        <script src="../assets/js/jquery.blockUI.js"></script>
        <script src="../assets/js/jquery.nicescroll.js"></script>

        <!-- App js -->
        <script src="../assets/js/admin.js"></script>

    </div>
    <!-- END main -->

    <!-- BEGIN Java Script for this page -->
    <script src="../assets/plugins/chart.js/Chart.min.js"></script>
    <script src="../assets/plugins/datatables/datatables.min.js"></script>

    <!-- Counter-Up-->
    <script src="../assets/plugins/waypoints/lib/jquery.waypoints.min.js"></script>
    <script src="../assets/plugins/counterup/jquery.counterup.min.js"></script>

    <!-- dataTabled data -->
    <script src="../assets/data/data_datatables.js"></script>

    <!-- Charts data -->
    <script src="../assets/data/data_charts_dashboard.js"></script>
    <script src="../assets/plugins/sweetalert.min.js"></script>
    <script src="../assets/plugins/fancybox/jquery.fancybox.min.js"></script>
    <!-- END Java Script for this page -->

    <script type="text/javascript">
        $(document).ready( function () {
            $('#table12').DataTable();
        } );
    </script>
    
        
</body>

</html>