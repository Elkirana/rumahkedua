<?php
echo '<script language="javascript">document.location="admin";</script>';