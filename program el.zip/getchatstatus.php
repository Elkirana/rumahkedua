<?php 
echo '{"status":"nomessage", "detail":"UNK"}'; ?>